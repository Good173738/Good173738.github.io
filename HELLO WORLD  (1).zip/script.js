document.addEventListener('DOMContentLoaded', () => {
    const app = document.getElementById('app');
    const screens = {
        welcome: document.getElementById('welcome-screen'),
        loading: document.getElementById('loading-screen'),
        registration: document.getElementById('registration-screen'),
        congratulations: document.getElementById('congratulations-screen'),
        vault: document.getElementById('vault-screen'),
        profile: document.getElementById('profile-screen'),
        camera: document.getElementById('camera')
    };

    function showScreen(screenId) {
        Object.values(screens).forEach(screen => screen.style.display = 'none');
        screens[screenId].style.display = 'block';
    }

    function toggleCameraVisibility(show) {
        screens.camera.style.display = show ? 'block' : 'none';
        document.getElementById('scan-qr-btn').style.display = show ? 'none' : 'block';
        document.getElementById('close-scan-btn').style.display = show ? 'block' : 'none';
        if (show) startCamera();
    }

    function startCamera() {
        const video = document.getElementById('video');
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } })
            .then(stream => {
                video.srcObject = stream;
                video.setAttribute('playsinline', true);
                video.play();
                requestAnimationFrame(scanQRCode);
            })
            .catch(err => {
                console.error('Error accessing camera: ', err);
            });

        function scanQRCode() {
            if (video.readyState === video.HAVE_ENOUGH_DATA) {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                context.drawImage(video, 0, 0, canvas.width, canvas.height);
                const imageData = context.getImageData(0, 0, canvas.width, canvas.height);
                const code = jsQR(imageData.data, canvas.width, canvas.height);
                if (code) {
                    alert(`Código QR escaneado: ${code.data}`);
                    toggleCameraVisibility(false); // Oculta la cámara después de escanear
                }
            }
            requestAnimationFrame(scanQRCode);
        }
    }

    document.getElementById('enter-btn').addEventListener('click', () => {
        showScreen('loading');
        setTimeout(() => showScreen('registration'), 2000); // Simula 2 segundos de carga
    });

    document.getElementById('registration-form').addEventListener('submit', (event) => {
        event.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        if (username && password) {
            localStorage.setItem('username', username);
            localStorage.setItem('password', password);
            document.getElementById('user-name').textContent = `Hola, ${username}`;
            showScreen('congratulations');
        }
    });

    document.getElementById('continue-btn').addEventListener('click', () => showScreen('vault'));

    document.getElementById('profile-icon').addEventListener('click', () => showScreen('profile'));

    document.getElementById('close-profile-btn').addEventListener('click', () => showScreen('vault'));

    document.getElementById('profile-form').addEventListener('submit', (event) => {
        event.preventDefault();
        const newUsername = document.getElementById('edit-username').value;
        const newPassword = document.getElementById('edit-password').value;

        if (newUsername) localStorage.setItem('username', newUsername);
        if (newPassword) localStorage.setItem('password', newPassword);

        const profileImage = document.getElementById('profile-image').files[0];
        if (profileImage) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const img = document.createElement('img');
                img.src = e.target.result;
                img.style.maxWidth = '100px';
                img.style.maxHeight = '100px';
                document.getElementById('profile-screen').appendChild(img);
            };
            reader.readAsDataURL(profileImage);
        }

        showScreen('vault');
    });

    document.getElementById('scan-qr-btn').addEventListener('click', () => toggleCameraVisibility(true));
    document.getElementById('close-scan-btn').addEventListener('click', () => toggleCameraVisibility(false));

    // Mostrar pantalla de bienvenida al cargar la página
    showScreen('welcome');
});